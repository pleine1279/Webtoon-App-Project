package WebtoonApp;

import java.io.IOException;
import javax.swing.*;

public class WebtoonApp {

	public static void main(String[] args) {
		Authentication auth = new Authentication();
        WebtoonManager manager = new WebtoonManager();
	    try {
	        manager.loadWebtoons("List.txt");
	    } catch (IOException e) {
	        System.out.println("웹툰 데이터를 로드하는 데 실패했습니다: " + e.getMessage());
	    }
	    
	    // 정렬된 웹툰을 가져와 UI에 전달
	    new UIpanel(manager.getSortedWebtoons());
	    if (showLoginDialog(auth)) {
            new UIpanel(manager.getWebtoons());
        } else {
            JOptionPane.showMessageDialog(null, "프로그램을 종료합니다.");
            System.exit(0);
        }
	}
	private static boolean showLoginDialog(Authentication auth) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel idLabel = new JLabel("ID:");
        JTextField idField = new JTextField(10);
        JLabel passLabel = new JLabel("Password:");
        JPasswordField passField = new JPasswordField(10);

        panel.add(idLabel);
        panel.add(idField);
        panel.add(passLabel);
        panel.add(passField);

        while (true) {
            int option = JOptionPane.showConfirmDialog(null, panel, "로그인", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                String id = idField.getText();
                String password = new String(passField.getPassword());

                if (auth.login(id, password)) {
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "아이디 혹은 비밀번호가 잘못되었습니다.");
                }
            } else {
                return false;
            }
        }
    }
}