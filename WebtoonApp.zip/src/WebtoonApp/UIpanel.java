package WebtoonApp;

import java.awt.*;
import java.io.*;
import javax.swing.*;

public class UIpanel extends JFrame {
	public UIpanel(Webtoon[] webtoons) {
		super("웹툰 웹 이름");
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    Container c = getContentPane();
	    c.setLayout(new BorderLayout());

	    CenterPanel centerPanel = new CenterPanel(webtoons);
	    c.add(new NorthPanel(webtoons, centerPanel), BorderLayout.NORTH);
	    c.add(centerPanel, BorderLayout.CENTER);
	    
	    JScrollPane scrollPane = new JScrollPane(centerPanel);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
	    c.add(scrollPane, BorderLayout.CENTER);

	    setSize(700, 1000);
	    setVisible(true);
	}
	
	class NorthPanel extends JPanel {
		public NorthPanel(Webtoon[] webtoons, CenterPanel centerPanel) {
	        setLayout(new BorderLayout());

	        // 상단 패널 (검색 필드와 버튼)
	        JPanel topPanel = new JPanel(new BorderLayout());
	        
	        JButton menuBtn = new JButton("메뉴");
	        menuBtn.setPreferredSize(new Dimension(50, 30));
	        topPanel.add(menuBtn, BorderLayout.WEST);

	        JTextField searchField = new JTextField();
	        topPanel.add(searchField, BorderLayout.CENTER);

	        JButton searchBtn = new JButton("검색");
	        searchBtn.setPreferredSize(new Dimension(50, 30));
	        topPanel.add(searchBtn, BorderLayout.EAST);

	        add(topPanel, BorderLayout.NORTH);

	        // 정렬 버튼 패널 (오른쪽에 위치)
	        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
	        JButton sortBtn = new JButton("정렬");
	        sortBtn.setPreferredSize(new Dimension(70, 30));
	        bottomPanel.add(sortBtn);
	        add(bottomPanel, BorderLayout.SOUTH);

	        // 정렬 버튼 이벤트 리스너
	        sortBtn.addActionListener(e -> {
	            Webtoon[] sortedWebtoons = new WebtoonManager().getSortedWebtoons();
	            centerPanel.updateWebtoons(sortedWebtoons); // CenterPanel 업데이트
	        });
	    }
	}
	class CenterPanel extends JPanel {
		private Webtoon[] webtoons;
		
	    public CenterPanel(Webtoon[] webtoons) {
	    	this.webtoons = webtoons;
	        initializeUI();
	        
	        setLayout(new GridBagLayout());
	        GridBagConstraints gbc = new GridBagConstraints();

	        gbc.insets = new Insets(10, 10, 10, 10);
	        gbc.fill = GridBagConstraints.NONE;
	        gbc.anchor = GridBagConstraints.CENTER;
	        gbc.weightx = 0;
	        gbc.weighty = 0;

	        int columns = 4;
	        int rows = (int) Math.ceil((double) webtoons.length / columns);

	        for (int i = 0; i < webtoons.length && webtoons[i] != null; i++) {
	            int row = i / columns;
	            int col = i % columns;

	            gbc.gridx = col;
	            gbc.gridy = row;

	            add(WebtoonPanel(webtoons[i]), gbc);
	        }

	        int totalCells = rows * columns;
	        for (int i = webtoons.length; i < totalCells; i++) {
	            gbc.gridx = i % columns;
	            gbc.gridy = i / columns;
	            add(PlaceholderPanel(), gbc);
	        }
	        
	    }

	    private JPanel WebtoonPanel(Webtoon webtoon) {
	        JPanel panel = new JPanel();
	        panel.setLayout(new BorderLayout());
	        panel.setPreferredSize(new Dimension(150, 240));
	        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

	        String imgPath = "images/" + webtoon.getTitle() + ".jpg";
	        JLabel imgLabel;


	        if (new File(imgPath).exists()) {
	            ImageIcon imgIcon = new ImageIcon(new ImageIcon(imgPath).getImage().getScaledInstance(150, 200, Image.SCALE_SMOOTH));
	            imgLabel = new JLabel(imgIcon, SwingConstants.CENTER);
	        } else {
	            imgLabel = new JLabel("이미지 없음", SwingConstants.CENTER);
	        }

	        imgLabel.setPreferredSize(new Dimension(150, 200)); // 이미지 크기 고정

	        JLabel nameLabel = new JLabel(webtoon.getTitle(), SwingConstants.CENTER);

	        panel.add(imgLabel, BorderLayout.CENTER);
	        panel.add(nameLabel, BorderLayout.SOUTH);

	        return panel;
	    }

	    private JPanel PlaceholderPanel() {
	        JPanel panel = new JPanel();
	        panel.setLayout(new BorderLayout());
	        panel.setPreferredSize(new Dimension(150, 240)); // 패널 크기 고정
	        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY));

	        JLabel imgLabel = new JLabel("빈 칸", SwingConstants.CENTER);
	        imgLabel.setPreferredSize(new Dimension(150, 200)); // 이미지 크기 고정

	        panel.add(imgLabel, BorderLayout.CENTER);
	        return panel;
	    }
	    private void initializeUI() {
	        removeAll();
	        setLayout(new GridBagLayout());
	        GridBagConstraints gbc = new GridBagConstraints();
	        gbc.insets = new Insets(10, 10, 10, 10);

	        int columns = 4;
	        for (int i = 0; i < webtoons.length && webtoons[i] != null; i++) {
	            int row = i / columns;
	            int col = i % columns;

	            gbc.gridx = col;
	            gbc.gridy = row;

	            add(WebtoonPanel(webtoons[i]), gbc);
	        }
	        revalidate();
	        repaint();
	    }

	    public void updateWebtoons(Webtoon[] newWebtoons) {
	        this.webtoons = newWebtoons;
	        initializeUI(); // 화면 업데이트
	    }
	}
}