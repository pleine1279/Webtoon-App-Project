package WebtoonApp;

public class Webtoon {
    private String title;
    private String author;
    private String genre;
    private int day;
    private double rate;
    private int platform;

    public Webtoon(String title, String author, String genre, int day, double rate, int platform) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.day = day;
        this.rate = rate;
        this.platform = platform;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    public String getDay() {
        // 요일을 숫자에 따라 문자열로 반환
        switch (day) {
            case 0: return "월";
            case 1: return "화";
            case 2: return "수";
            case 3: return "목";
            case 4: return "금";
            case 5: return "토";
            case 6: return "일";
            case 7: return "매일";
            default: return "알 수 없음";
        }
    }

    public double getRate() {
        return rate;
    }
    
    public int getPlatform() {
        return platform;
    }
}