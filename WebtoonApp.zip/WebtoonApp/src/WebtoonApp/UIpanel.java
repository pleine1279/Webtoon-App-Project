package WebtoonApp;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.*;

public class UIpanel extends JFrame {
    public UIpanel(WebtoonManager manager) {
        super("웹툰 웹 이름");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container c = getContentPane();
        c.setLayout(new BorderLayout());

        CenterPanel centerPanel = new CenterPanel(manager.getWebtoons());
        JScrollPane scrollPane = new JScrollPane(centerPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        c.add(new NorthPanel(manager, centerPanel), BorderLayout.NORTH);
        c.add(scrollPane, BorderLayout.CENTER);

        setSize(700, 1000);
        setVisible(true);
    }

    class NorthPanel extends JPanel {
        public NorthPanel(WebtoonManager manager, CenterPanel centerPanel) {
            setLayout(new BorderLayout());
            
            JPanel topPanel = new JPanel(new BorderLayout());

            JButton menuBtn = new JButton("...");
            menuBtn.setPreferredSize(new Dimension(50, 30));
            topPanel.add(menuBtn, BorderLayout.WEST);

            JTextField searchField = new JTextField();
            topPanel.add(searchField, BorderLayout.CENTER);

            JButton searchBtn = new JButton("검색");
            searchBtn.setPreferredSize(new Dimension(50, 30));
            topPanel.add(searchBtn, BorderLayout.EAST);

            add(topPanel, BorderLayout.NORTH);

            JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            JButton sortBtn = new JButton("정렬");
            sortBtn.setPreferredSize(new Dimension(70, 30));
            bottomPanel.add(sortBtn);
            add(bottomPanel, BorderLayout.SOUTH);

            menuBtn.addActionListener(e -> openMenuWindow());

            sortBtn.addActionListener(e -> {
                Webtoon[] sortedWebtoons = manager.getSortedWebtoons();
                centerPanel.updateWebtoons(sortedWebtoons); 
            });
        }

        private void openMenuWindow() {
           
            JFrame menuFrame = new JFrame("메뉴");
            menuFrame.setSize(300, 200);
            menuFrame.setLayout(new GridLayout(5, 1));

            JButton naverBtn = createLinkButton("네이버 웹툰", "https://comic.naver.com/");
            JButton kakaoBtn = createLinkButton("카카오 웹툰", "https://webtoon.kakao.com/");
            JButton lezhinBtn = createLinkButton("레진코믹스", "https://www.lezhin.com/");

            JButton logoutBtn = new JButton("로그아웃");
            logoutBtn.addActionListener(e -> {
                JOptionPane.showMessageDialog(null, "로그아웃 되었습니다.");
                menuFrame.dispose();
                dispose();
            });

            menuFrame.add(naverBtn);
            menuFrame.add(kakaoBtn);
            menuFrame.add(lezhinBtn);
            menuFrame.add(new JLabel("")); 
            menuFrame.add(logoutBtn);

            menuFrame.setVisible(true);
        }

        private JButton createLinkButton(String text, String url) {
            JButton button = new JButton(text);
            button.addActionListener(e -> {
                try {
                    Desktop.getDesktop().browse(new URI(url));
                } catch (IOException | URISyntaxException ex) {
                    JOptionPane.showMessageDialog(null, "링크를 열 수 없습니다.");
                }
            });
            return button;
        }
    }


    class CenterPanel extends JPanel {
        private Webtoon[] webtoons;

        public CenterPanel(Webtoon[] webtoons) {
            this.webtoons = webtoons;
            initializeUI();
        }

        private void initializeUI() {
            removeAll();
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);

            int columns = 4;
            for (int i = 0; i < webtoons.length; i++) {
                int row = i / columns;
                int col = i % columns;

                gbc.gridx = col;
                gbc.gridy = row;

                add(createWebtoonPanel(webtoons[i]), gbc);
            }
            revalidate();
            repaint();
        }

        private JPanel createWebtoonPanel(Webtoon webtoon) {
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout());
            panel.setPreferredSize(new Dimension(150, 240));
            panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            JLabel titleLabel = new JLabel(webtoon.getTitle(), SwingConstants.CENTER);
            JLabel authorLabel = new JLabel("작가: " + webtoon.getAuthor(), SwingConstants.CENTER);

            panel.add(titleLabel, BorderLayout.NORTH);
            panel.add(authorLabel, BorderLayout.CENTER);

            return panel;
        }

        public void updateWebtoons(Webtoon[] newWebtoons) {
            this.webtoons = newWebtoons;
            initializeUI();
        }
    }
}