package WebtoonApp;

import java.util.*;

public class Authentication {
	private List<User_manager> list;
	private User_manager liveUser;
	
	public Authentication() {
		this.list = new ArrayList<>();
		list.add(new User_manager("SHS", "0000"));
		list.add(new User_manager("SJC", "0000"));
	}
	
	public boolean login(String id, String password) {
		for (int i = 0; i < list.size(); i++) {
			User_manager user = list.get(i);
			if (user.getID().equals(id) && user.getPassword().equals(password)) {
				liveUser = user;
				System.out.println("로그인 되었습니다.");
				return true;
			}
		}
		System.out.println("아이디 혹은 비밀번호를 확인해주세요.");
		return false;
	}
	
	public void logout() {
		if (liveUser != null) {
			System.out.println("로그아웃 되었습니다.");
			liveUser = null;
		}
		else
			System.out.println("로그인 상태가 아닙니다.");
	}
	
	public User_manager getLiveuser() {
		return liveUser;
	}
}
